public class Coche extends Vehiculo {
    
    public Coche(String marca, String modelo, int ano, double velocidadMaxima) throws VelocidadInvalidaException {
        super(marca, modelo, ano, velocidadMaxima);
    }

    @Override
    public void arrancar() {
        System.out.println("El coche ruge al arrancar");
    }
}