import java.util.ArrayList;
import java.util.Scanner;

public class AppVehiculos {
    
    public static void main(String[] args) {
        
        ArrayList<Vehiculo> vehiculos = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Sistema de Gestión de Vehiculos ===");
            System.out.println("1. Añadir Coche");
            System.out.println("2. Añadir Moto");
            System.out.println("3. Añadir Bicicleta");
            System.out.println("4. Añadir Camion");
            System.out.println("5. Añadir Patinete");
            System.out.println("6. Mostrar todos los vehiculos y arrancar");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opcion (1-7): ");

            int opcion;
            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un numero valido.");
                continue;
            }

            if (opcion == 7) {
                System.out.println("¡Saliendo del programa!");
                break;
            }

            if (opcion == 6) {
                if (vehiculos.isEmpty()) {
                    System.out.println("No hay vehiculos registrados.");
                } else {
                    System.out.println("\n=== Lista de Vehiculos ===");
                    for (Vehiculo vehiculo : vehiculos) {
                        System.out.println(vehiculo.toString());
                        vehiculo.arrancar();
                        System.out.println("------------------------");
                    }
                }
                continue;
            }

            if (opcion < 1 || opcion > 5) {
                System.out.println("Opcion no valida. Por favor, seleccione entre 1 y 7.");
                continue;
            }

            // Solicitar datos del vehículo
            System.out.print("Ingrese la marca: ");
            String marca = scanner.nextLine();

            System.out.print("Ingrese el modelo: ");
            String modelo = scanner.nextLine();

            System.out.print("Ingrese el año: ");
            int anio;
            try {
                anio = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: El año debe ser un numero valido.");
                continue;
            }

            System.out.print("Ingrese la velocidad maxima (km/h): ");
            double velocidadMaxima;
            try {
                velocidadMaxima = Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: La velocidad maxima debe ser un numero valido.");
                continue;
            }

            // Crear el vehículo según la opción seleccionada
            try {
                switch (opcion) {
                    case 1:
                        vehiculos.add(new Coche(marca, modelo, anio, velocidadMaxima));
                        System.out.println("Coche añadido con exito.");
                        break;
                    case 2:
                        vehiculos.add(new Moto(marca, modelo, anio, velocidadMaxima));
                        System.out.println("Moto añadida con exito.");
                        break;
                    case 3:
                        vehiculos.add(new Bicicleta(marca, modelo, anio, velocidadMaxima));
                        System.out.println("Bicicleta añadida con exito.");
                        break;
                    case 4:
                        vehiculos.add(new Camion(marca, modelo, anio, velocidadMaxima));
                        System.out.println("Camión añadido con exito.");
                        break;
                    case 5:
                        vehiculos.add(new Patinete(marca, modelo, anio, velocidadMaxima));
                        System.out.println("Patinete añadido con exito.");
                        break;
                }
            } catch (VelocidadInvalidaException e) {
                System.out.println("Error al añadir vehiculo: " + e.getMessage());
            }
        }

        scanner.close();
    }
}