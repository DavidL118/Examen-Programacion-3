public class VelocidadInvalidaException extends Exception {
    
    public VelocidadInvalidaException(String mensaje) {
        
        super(mensaje);
        
    }
}