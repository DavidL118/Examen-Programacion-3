public abstract class Vehiculo {
    
    private String marca;
    private String modelo;
    private int ano;
    private double velocidadMaxima;

    public Vehiculo(String marca, String modelo, int ano, double velocidadMaxima) throws VelocidadInvalidaException {
        
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        setVelocidadMaxima(velocidadMaxima);
        
    }

    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }
    public int getAnio() { return ano; }
    public void setAnio(int anio) { this.ano = anio; }

    public double getVelocidadMaxima() { return velocidadMaxima; }
    public void setVelocidadMaxima(double velocidadMaxima) throws VelocidadInvalidaException {
        if (velocidadMaxima <= 0) {
            throw new VelocidadInvalidaException("La velocidad maxima debe ser mayor que 0");
        }
        this.velocidadMaxima = velocidadMaxima;
    }

    public abstract void arrancar();

    @Override
    public String toString() {
        return "Vehiculo: " + marca + " " + modelo + ", Año: " + ano + ", Vel. Máx.: " + velocidadMaxima + " km/h";
    }
}
